const express = require('express');
const path = require('path');
const app = express();
app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => { res.sendFile(path.join(__dirname, 'public', 'index.html')); });

let userLedger = {};
let withdrawalRequests = [];

app.post('/api/user/login', (req, res) => {
    const { phone } = req.body;
    if(!phone || phone.length < 10) return res.json({ success: false, message: "Sahi number dalo!" });
    if(!userLedger[phone]) { userLedger[phone] = { coins: 0, watchedAds: 0 }; }
    res.json({ success: true, data: userLedger[phone] });
});

app.post('/api/reward/ad-flexible', (req, res) => {
    const { phone, coinsToAdd } = req.body;
    if(!userLedger[phone]) return res.json({ success: false });
    userLedger[phone].coins += Number(coinsToAdd); 
    userLedger[phone].watchedAds += 1;
    res.json({ success: true, newBalance: userLedger[phone].coins });
});

app.post('/api/user/withdraw', (req, res) => {
    const { phone, type, details, amountCoins } = req.body;
    if(!userLedger[phone] || userLedger[phone].coins < Number(amountCoins)) {
        return res.json({ success: false, message: "Coins kam hain bhai!" });
    }
    userLedger[phone].coins -= Number(amountCoins);
    withdrawalRequests.push({ id: "req_" + Date.now(), phone, type, details, coinsUsed: amountCoins, status: "PENDING" });
    res.json({ success: true, newBalance: userLedger[phone].coins, message: "Claim request received successfully!" });
});

app.listen(3000, () => console.log("🚀 ENGINE ALIVE ON PORT 3000..."));
